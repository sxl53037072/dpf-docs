## 引入依赖及配置【当前项目中已经默认配置上了，可以忽略本章】

1. 引入框架依赖包(基于MAVEN进行引入)
	```xml
	<dependency>
       <groupId>com.dpf</groupId>
       <artifactId>transaction</artifactId>
       <version>1.1.4</version>
    </dependency>
	```
2. 在spring配置文件applicationContext.xml中加入初始化bean
	```xml
	<bean class="com.dpf.transaction.context.ContextLoaderInit"/>
	<bean id="transactionService" class="com.dpf.transaction.service.JsonTransactionService"/>
	```
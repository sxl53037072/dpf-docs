## 调用接口
### 前端访问

1. 目前前端提供两个方法直接可以通过AJAX进行调用

| 方法名                                        | 含义                                                                                                        | 约束                          |
| -------------                                |:-------------:                                                                                              | :-------------:                |
| /tran/doTran?act=demo.tran.select           | 执行一般的事务操作 返回格式 {rows:[],"message":"","status":"1"}                                                |  必须提供act参数，act:事务名称，rows:具体数据， message：错误信息一般为空， status:1=成功,0=失败    |
| /tran/doTranPaging?act=demo.tran.select     | 执行分页的事务查询 返回格式{rows:[],"message":"","status":"1",total:"总条数",totalPage:"总页数",page:"当前页码"}   |  必须提供act参数，act:事务名称, 会自动查询 act.count 统计总条数，总条数事务必须返回count字段    |

>请求参数支持以下几种
>1. act: 参数标识需要执行操作的事务名称，必须在配置文件中声明
>2. cacheName: 替代act参数，表示先从缓存中读取对应事务的数据，如果缓存中没有数据则再从数据库中读取，读取的数据回填入缓存。原则上  缓存优先于数据库
>3. cacheRefresh： 可选，值为1表示优先从数据库提取数据，提前完成刷新缓存。

***
### 后端访问

1. 后端目前提供有5个服务层方法供后端代码调用，需要注入服务方法 TransactionService
	```java
	@Autowired
    private TransactionService transactionService;
	```

| 方法名                                        | 参数                                   | 返回值                                                 | 约束                                              |
| -------------                                |:-------------:                         | :-------------:                                       | :-------------:                                   |
| doTran                                       | tranName：事务名称  param：参数map  | 结果集JSON对象 {rows:[{},{}...],message:xxx,status:xxx} | 可用于CRUD操作，返回为JSON对象                      |
| doTranList                                   | tranName：事务名称  param：参数map  | 结果集List对象                                          | 对doTran方法的进一步封装，将结果集包装成list对象      |
| doTranMap                                    | tranName：事务名称  param：参数map  | 结果集Map对象                                           | 对doTran方法的进一步封装，将结果集包装成map对象      |
| doTranString                                 | tranName：事务名称  param：参数map  | 结果集String对象                                        | 对doTran方法的进一步封装，将结果集包装成String类型      |
| doTranPaging                                 | tranName：事务名称  param：参数map  | 结果集JSON对象 {rows:[],"message":"","status":"1",total:"总条数",totalPage:"总页数",page:"当前页码"}    |  必须提供act参数，act:事务名称, 会自动查询 act.count 统计总条数，总条数事务必须返回count字段      |


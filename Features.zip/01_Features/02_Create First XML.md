
## 创建第一个配置文件

1. 在JAVA目录中新建包 com.dpf.transactions
2. 在该包中新建一个文件 demo.transaction, 注意文件后缀为transaction
3. 在该文件中写入第一个事务方法如下
	```xml
	<transaction name="demo.test.select" event="select" return="true">
	    <sql>
	        select * from t_test
	    </sql>
	</transaction>
	```
4. 现在我们可以在在HTML页面直接通过AJAX访问，访问URL为 
	```url
	/tran/doTran?act=demo.test.select
	```
   这将返回JSON对象，格式为：
	```json
	{rows:[],"message":"","status":"1"}
	```
5. 到这里我们已经完成了从前端>后端>数据库的查询操作,接下来我们开始学习事务方法的各个标签含义






























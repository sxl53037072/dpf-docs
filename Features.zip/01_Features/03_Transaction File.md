## 配置文件标签解析
* 下面以这些事务方法来了解配置文件各个标签的含义
1. **查询事务**,直接返回整表数据。
	```xml
	<!--查询test表数据-->
	<transaction name="demo.test.select" event="select" return="true">
	    <sql>
	        select * from T_TEST_TRAN
	    </sql>
	</transaction>
	```
2. **新增事务**,包含前置查询序列,并且在新增完毕后返回序列。
	```xml
	<!--1.1前置查询sequence-->
	<transaction name="demo.test.insert.seq.select" event="function" return="true">
        <sql>
            select nextval('seq_test_tran') as "seq"
        </sql>
        <variable name="seq">seq</variable>
    </transaction>
	<!--1.2执行新增操作-->
	<transaction name="demo.test.insert" event="insert">
        <refer name="demo.test.insert.seq.select" type="before" />
	    <sql>
	     	insert into T_TEST_TRAN(id, name, age, email, phone, remark, create_time)
          		select :seq, :name, :age, :email, :phone, :remark, now()
	    </sql>
	</transaction>
	```
3. **更新事务**,根据参数进行数据更新,对参数进行空判断。
	```xml
	<!--更新test表数据-->
	<transaction name="demo.tran.update" event="update">
        <sql>
            update T_TEST_TRAN
            set name = :name,
                age = :age,
                email = :email,
                phone = :phone,
                remark = :remark
            <if test="id != null">
                where id = :id
            </if>
            <if test="id == null">
                where 1 = 2
            </if>
        </sql>
    </transaction>
	```
4. **删除事务**,批量删除数据，id数值类似 1,2,3 事务会自动对参数进行拆分批量删除。
	```xml
	<!--删除test表对应主键的数据-->
	<transaction name="demo.tran.delete" event="batch">
        <sql>
            delete from  T_TEST_TRAN            
            <if test="id != null">
                where id = ?
            </if>
            <if test="id == null">
                where 1 = 2
            </if>
        </sql>
		<parameter name="id" from="json" split="true"><bind>1</bind></parameter>
    </transaction>
	```
* **事务标签含义**

| 标签          | 含义                                     | 约束                          |
| ------------- |:-------------:                          | :-------------:                |
| transaction   | 事务方法标签                              | 在一个配置文件中可以有N个该标签 |
| sql           | sql标签，用来写入需要执行的SQL             |   每个事务方法1个该标签 |
| refer         | 依赖事务方法包括前置依赖和后置依赖           |  每个事务方法可以引入多个依赖    |
| parameter     | 参数注入                                  |  每个事务方法可以多个参数注入配置    |
| variable      | 变量赋值                                  |  配合function事务进行变量赋值，变量在整个事务生命周期中都可以读取到 |	
* 每个事务标签的属性及值含义

1. **transaction**

| 属性           | 含义                                     | 约束                          |
| ------------- |:-------------:                          | :-------------:                |
| name          | 事务名称                                  | 1.必须全局唯一 <br /> 2.第一个点号前的文字需要和事务文件名相同 <br /> 3.事务名结尾必须是CURD标识，如insert,select等 |
| event         | 事务执行的动作含义                         | 1.select:查询事务 <br /> 2.insert：新增事务 <br /> 3.delete:删除事务 <br /> 4.update:更新事务 <br /> 5.function 函数事务 <br /> 6.batch 批处理事务 |
| return        | 是否返回，可不写                           |  可不写，只有值只能为true,标识返回事务查询的内容    |
| 值            | 整个事务的配置                             |      |

2. **sql**

| 属性           | 含义                                     | 约束                          |
| ------------- |:-------------:                           | :-------------:                |
| 值            | 事务的SQL语句，参数以:开头进行配置           |  特殊字符参照XML标准    |

3. **refer**

| 属性           | 含义                                     | 约束                          |
| ------------- |:-------------:                           | :-------------:                |
| name           | 依赖事务的名称                            |  尽量依赖于本配置文件中的事务    |
| type           | 依赖顺序                                 |  before:前置事务；after:后置事务    |

4. **parameter**

| 属性           | 含义                                     | 约束                          |
| ------------- |:-------------:                           | :-------------:                |
| name           | 参数名，对应传入的参数                     |      |
| from           | 参数来源                                 |  1.constant:静态变量，其后必须跟上对应的value值 <br /> 2.json:json对象 <br /> 3.variable:前置事务传递下来的变量<br /> 4.xml:待定    |
| value          | 参数值，可不写                            |  当from=constant时，该属性标识静态变量的值    |
| path           | 访问层级，可不写                           |  当from=json时，该属性标识json访问的层级    |
| split          | 批量事务中，需要对参数进行split切割时使用    |  参数为1,2,3,4将其分词拆分为多个SQL进行批量新增/更新/删除，配合event=batch使用 ，event=delete也可以使用    |
| 值             | 参数绑定的？位置，从1开始                   |  只能包含<bing></bind>标签，标识参数绑定的？位置，可以同时绑定多个？如<bing>1</bind><bing>2</bind>标识绑定第一个和第二个?  |

5. **variable**

| 属性           | 含义                                     | 约束                          |
| ------------- |:-------------:                           | :-------------:                |
| name           | 参数名 引用事务通过variable进行调用        |                    |
| 值             | sql返回的对应别名                         |   配合type="function"一起使用     |

###
  